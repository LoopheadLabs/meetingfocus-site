/**
 * MeetingFocus - Options Page Script
 */

// ============================================================
// ExtensionPay (Stripe-backed license)
// ============================================================

const extpay = ExtPay('meetingfocus');

// ============================================================
// DOM refs
// ============================================================

const licenseStatus = document.getElementById('license-status');
const licenseActions = document.getElementById('license-actions');
const prefAudioGate = document.getElementById('pref-audio-gate');
const prefNewTabMute = document.getElementById('pref-new-tab-mute');
const prefBadge = document.getElementById('pref-badge');
const meetingLog = document.getElementById('meeting-log');
const exportCsvBtn = document.getElementById('export-csv-btn');
const clearLogBtn = document.getElementById('clear-log-btn');
const resetBtn = document.getElementById('reset-btn');

// ============================================================
// Init
// ============================================================

async function init() {
  await renderLicenseStatus();
  await loadPreferences();
  await renderMeetingLog();
}

// ============================================================
// License
// ============================================================

async function renderLicenseStatus() {
  // Fast path: cached storage value. Then reconcile with ExtPay in the
  // background so a cross-device purchase or refund updates the UI.
  const cached = await chrome.storage.local.get({ isPaid: false });
  paintLicense(cached.isPaid);

  try {
    const user = await extpay.getUser();
    const live = !!user.paid;
    if (live !== cached.isPaid) {
      await chrome.storage.local.set({ isPaid: live });
      paintLicense(live);
      await renderMeetingLog();
    }
  } catch (e) {
    // Offline or ExtPay unreachable; cached state remains.
  }
}

function paintLicense(paid) {
  if (paid) {
    licenseStatus.innerHTML = '<div class="status-text paid">MeetingFocus Pro (licensed)</div>';
    licenseActions.innerHTML = '';
  } else {
    licenseStatus.innerHTML = '<div class="status-text free">Free plan. Upgrade for session restore, profiles, meeting log, and unlimited allowlist.</div>';
    licenseActions.innerHTML = '<button class="btn btn-accent" id="upgrade-options-btn">Upgrade for $14.99</button>';
    document.getElementById('upgrade-options-btn').addEventListener('click', () => {
      extpay.openPaymentPage('pro');
    });
  }
}

// ============================================================
// Preferences
// ============================================================

async function loadPreferences() {
  const result = await chrome.storage.local.get({
    prefs: {
      audioGate: true,
      newTabMute: true,
      showBadge: true
    }
  });

  prefAudioGate.checked = result.prefs.audioGate;
  prefNewTabMute.checked = result.prefs.newTabMute;
  prefBadge.checked = result.prefs.showBadge;
}

async function savePreferences() {
  const prefs = {
    audioGate: prefAudioGate.checked,
    newTabMute: prefNewTabMute.checked,
    showBadge: prefBadge.checked
  };
  await chrome.storage.local.set({ prefs });
}

prefAudioGate.addEventListener('change', savePreferences);
prefNewTabMute.addEventListener('change', savePreferences);
prefBadge.addEventListener('change', savePreferences);

// ============================================================
// Meeting log
// ============================================================

async function renderMeetingLog() {
  const result = await chrome.storage.local.get({ isPaid: false, meetingHistory: [] });

  if (!result.isPaid) {
    meetingLog.innerHTML = '<div class="empty-state">Upgrade to Pro to track your meeting history.</div>';
    exportCsvBtn.disabled = true;
    clearLogBtn.disabled = true;
    return;
  }

  const history = result.meetingHistory;

  if (history.length === 0) {
    meetingLog.innerHTML = '<div class="empty-state">No meetings logged yet. History appears after your first MeetingFocus session.</div>';
    return;
  }

  // Show most recent first
  const rows = [...history].reverse().map(entry => {
    const date = new Date(entry.date);
    const dateStr = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    const timeStr = date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    const mins = Math.floor(entry.duration / 60);
    const secs = entry.duration % 60;
    const durStr = `${mins}m ${secs}s`;

    return `<tr>
      <td>${dateStr} ${timeStr}</td>
      <td>${escapeHtml(entry.platform)}</td>
      <td>${durStr}</td>
      <td>${entry.tabsMuted}</td>
    </tr>`;
  }).join('');

  meetingLog.innerHTML = `
    <table class="meeting-log-table">
      <thead>
        <tr>
          <th>Date</th>
          <th>Platform</th>
          <th>Duration</th>
          <th>Tabs muted</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

// ============================================================
// Export CSV
// ============================================================

exportCsvBtn.addEventListener('click', async () => {
  const result = await chrome.storage.local.get({ meetingHistory: [] });
  if (result.meetingHistory.length === 0) return;

  const header = 'Date,Platform,Duration (seconds),Tabs Muted\n';
  const rows = result.meetingHistory.map(e =>
    `"${e.date}","${e.platform}",${e.duration},${e.tabsMuted}`
  ).join('\n');

  const csv = header + rows;
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `meetingfocus-history-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

// ============================================================
// Clear history
// ============================================================

clearLogBtn.addEventListener('click', async () => {
  if (confirm('Clear all meeting history? This cannot be undone.')) {
    await chrome.storage.local.set({ meetingHistory: [] });
    await renderMeetingLog();
  }
});

// ============================================================
// Reset all
// ============================================================

resetBtn.addEventListener('click', async () => {
  if (confirm('Reset all MeetingFocus settings, allowlist, and history? This cannot be undone.')) {
    await chrome.storage.local.clear();
    location.reload();
  }
});

// ============================================================
// Utility
// ============================================================

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ============================================================
// Start
// ============================================================

init();
